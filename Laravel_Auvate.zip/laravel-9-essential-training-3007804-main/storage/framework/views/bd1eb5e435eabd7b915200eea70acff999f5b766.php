<?php if(session('success')): ?>
    <div class="mb-4 px-4 py-2 bg-green-100 border border-green-200 text-green-700 rounded-md">
        <?php echo e($slot); ?>

    </div>
<?php endif; ?><?php /**PATH D:\testlaravel\laravel-9-essential-training-3007804-main\laravel-9-essential-training-3007804-main\resources\views/components/alert-success.blade.php ENDPATH**/ ?>